//
//  FaveButton.h
//  FaveButton
//
//  Created by Jansel Valentin on 6/12/16.
//  Copyright © 2016 Jansel Valentin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FaveButton.
FOUNDATION_EXPORT double FaveButtonVersionNumber;

//! Project version string for FaveButton.
FOUNDATION_EXPORT const unsigned char FaveButtonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaveButton/PublicHeader.h>


