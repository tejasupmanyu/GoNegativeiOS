//
//  CDAlertView.h
//  CDAlertView
//
//  Created by Candost Dagdeviren on 29/11/2016.
//  Copyright © 2016 Candost Dagdeviren. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CDAlertView.
FOUNDATION_EXPORT double CDAlertViewVersionNumber;

//! Project version string for CDAlertView.
FOUNDATION_EXPORT const unsigned char CDAlertViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CDAlertView/PublicHeader.h>


