//
//  KMPlaceholderTextView.h
//  KMPlaceholderTextView
//
//  Created by Zhouqi Mo on 8/16/15.
//  Copyright (c) 2015 Zhouqi Mo. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KMPlaceholderTextView.
FOUNDATION_EXPORT double KMPlaceholderTextViewVersionNumber;

//! Project version string for KMPlaceholderTextView.
FOUNDATION_EXPORT const unsigned char KMPlaceholderTextViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KMPlaceholderTextView/PublicHeader.h>


